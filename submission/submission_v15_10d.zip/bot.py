import os
import re
import time
import math
import random
import hashlib

import eval7

try:
    import numpy as np
    _NUMPY_OK = True
except Exception:
    np = None
    _NUMPY_OK = False

BOT_NAME = "OurBot v13"
HANDS_PER_MATCH = 400
SOFT_BUDGET = 0.8
_T0 = 0.0

RIVER_FOLD = float(os.environ.get("RIVER_FOLD", "0.50"))

DATA_DIR = os.environ.get("BOT_DATA_DIR",
                          os.path.join(os.path.dirname(__file__), "data"))

HAND_COUNT = 0
POSTFLOP_DECISIONS = 0
FALLBACK_DECISIONS = 0

DEFAULT_BB = 100
SHORT_STACK_BB = 15
RANKS = "23456789TJQKA"
RANK_VAL = {r: i for i, r in enumerate(RANKS)}

POSTFLOP_STRATEGY_TABLE = {}

def _expand_token(tok):
    tok = tok.strip()
    if not tok:
        return set()
    plus = tok.endswith("+")
    core = tok[:-1] if plus else tok
    out = set()
    if len(core) == 2 and core[0] == core[1] and core[0] in RANK_VAL:
        lo = RANK_VAL[core[0]]
        hi = RANK_VAL["A"] if plus else lo
        for v in range(lo, hi + 1):
            out.add(RANKS[v] * 2)
        return out
    if len(core) == 3 and core[0] in RANK_VAL and core[1] in RANK_VAL and core[2] in "so":
        a, b, suit = core[0], core[1], core[2]
        hv, lv = RANK_VAL[a], RANK_VAL[b]
        if hv < lv:
            hv, lv = lv, hv
        if plus:
            for k in range(lv, hv):
                out.add(RANKS[hv] + RANKS[k] + suit)
        else:
            out.add(RANKS[hv] + RANKS[lv] + suit)
        return out
    return out

def R(s):
    out = set()
    for tok in s.replace(",", " ").split():
        out |= _expand_token(tok)
    return out

OPEN = {
    'UTG': R("22+, ATs+, KTs+, QTs+, JTs, T9s, AJo+, KQo"),
    'HJ':  R("22+, A9s+, A5s, KTs+, Q9s+, J9s+, T9s, 98s, ATo+, KJo+, QJo"),
    'CO':  R("22+, A2s+, K9s+, Q9s+, J9s+, T8s+, 98s, 87s, 76s, A9o+, A5o, KTo+, QTo+, JTo"),
    'BTN': R("22+, A2s+, K5s+, Q8s+, J8s+, T8s+, 97s+, 86s+, 75s+, 65s, 54s, A2o+, K9o+, Q9o+, J9o+, T9o"),
    'SB':  R("22+, A2s+, K7s+, Q8s+, J8s+, T8s+, 97s+, 86s+, 76s, 65s, A7o+, A5o, K9o+, Q9o+, JTo"),
    'BB':  R("55+, A8s+, KTs+, QTs+, JTs, T9s, ATo+, KQo"),
}
VS_OPEN_3BET = {
    'UTG': R("QQ+, AKs, AKo"),
    'HJ':  R("JJ+, AKs, AKo, A5s"),
    'CO':  R("JJ+, AQs+, AKo, A5s, KQs"),
    'BTN': R("TT+, AQs+, AKo, A5s, A4s, KQs"),
    'SB':  R("QQ+, AKs, AKo, A5s"),
    'BB':  R("QQ+, AKs, AKo, A5s"),
}
VS_OPEN_CALL = {
    'UTG': R("JJ-TT, AQs, AJs, KQs"),
    'HJ':  R("TT-77, AJs, ATs, KQs, KJs, QJs, JTs, AQo"),
    'CO':  R("99-22, ATs+, KJs+, QJs, JTs, T9s, 98s, AQo, AJo"),
    'BTN': R("TT-22, A9s+, KTs+, QTs+, J9s+, T9s, 98s, 87s, 76s, AJo, KQo"),
    'SB':  R("JJ-77, AJs, ATs, KQs, QJs, JTs"),
    'BB':  R("99-22, ATs+, KJs+, QJs, JTs, T9s, 98s, AQo, KQo"),
}
BLIND_DEFEND_3BET = {
    'SB': R("TT+, AJs+, KQs, AQo+, A5s, A4s"),
    'BB': R("TT+, AQs+, AKo, A5s, A4s, K5s"),
}
BLIND_DEFEND_CALL = {
    'SB': R("99-22, ATs-AJs, KQs, KJs, QJs, JTs, T9s, 98s, AJo, KQo"),
    'BB': R("99-22, A2s+, K7s+, Q8s+, J8s+, T8s+, 97s+, 86s+, 75s+, 64s+, 54s, "
            "A2o+, K9o+, Q9o+, J9o+, T9o"),
}
VS_3BET_4BET = {
    'UTG': R("KK+, AKs"), 'HJ': R("KK+, AKs, A5s"), 'CO': R("QQ+, AKs, A5s, A4s"),
    'BTN': R("QQ+, AKs, AKo, A5s, A4s"), 'SB': R("QQ+, AKs, A5s"), 'BB': R("KK+, AKs"),
}
VS_3BET_CALL = {
    'UTG': R("QQ-JJ, AQs, AKo"), 'HJ': R("QQ-TT, AQs, AJs, AKo, KQs"),
    'CO': R("JJ-99, AQs, AJs, AKo, KQs, KJs, QJs"),
    'BTN': R("JJ-88, AQs-ATs, AKo, KQs, KJs, QJs, JTs"),
    'SB': R("JJ-TT, AQs, AKo"), 'BB': R("QQ-TT, AQs, AKo, KQs"),
}
VS_4BET_CONT = R("KK+, AKs")
JAM_FIRST_IN = {
    'UTG': R("66+, ATs+, AJo+, KQs"), 'HJ': R("55+, A9s+, ATo+, KJs+, KQo"),
    'CO': R("44+, A7s+, A9o+, KTs+, KJo+, QJs"),
    'BTN': R("22+, A2s+, A7o+, A5o, K9s+, KTo+, Q9s+, QJo, J9s+, T9s"),
    'SB': R("22+, A2s+, A2o+, K5s+, K9o+, Q8s+, QTo+, J8s+, T8s+, 98s"),
    'BB': R("33+, A7s+, A9o+, KTs+, KQo, QJs"),
}
JAM_VS_RAISE = R("88+, ATs+, AQo+, KQs")

HU_SB_OPEN_FRAC   = 0.80
HU_BB_DEFEND_FRAC = 0.66
HU_BB_ISO_FRAC    = 0.28
HU_BB_3BET        = R("99+, ATs+, A5s, A4s, KTs+, QTs+, JTs, AJo+, KQo")
HU_SB_4BET        = R("QQ+, AKs, AKo, A5s")
HU_SB_VS_3BET_CALL = R("88-22, A9s+, KTs+, QTs+, JTs, T9s, AQo, AJo, KQo")
HU_5BET_CONT      = R("KK+, AKs")
HU_JAM_SB_FRAC    = 0.62
HU_JAM_DEF_FRAC   = 0.45

def _build_hand_rank_order():
    hands = []
    for a in range(13):
        for b in range(13):
            if a == b:
                hands.append(RANKS[a] * 2)
            elif a > b:
                hands.append(RANKS[a] + RANKS[b] + "s")
                hands.append(RANKS[a] + RANKS[b] + "o")

    def score(cls):
        if len(cls) == 2:
            return 140 + RANK_VAL[cls[0]] * 10
        hi, lo = RANK_VAL[cls[0]], RANK_VAL[cls[1]]
        suited = cls[2] == "s"
        s = hi * 5 + lo * 3
        gap = hi - lo
        if gap == 1:
            s += 6
        elif gap == 2:
            s += 3
        elif gap == 3:
            s += 1
        if suited:
            s += 8
        if lo >= RANK_VAL["T"]:
            s += 6
        if cls[0] == "A":
            s += 4
        return s

    return sorted(hands, key=score, reverse=True)

HAND_RANK_ORDER = _build_hand_rank_order()
N_HANDS = len(HAND_RANK_ORDER)

def defend_top(frac):
    k = max(1, min(N_HANDS, int(round(N_HANDS * frac))))
    return set(HAND_RANK_ORDER[:k])

def classify_raise_size(amount_to_call, big_blind=DEFAULT_BB):
    bb = big_blind or DEFAULT_BB
    if amount_to_call <= 1.5 * bb:
        return "min_raise"
    if amount_to_call <= 2.5 * bb:
        return "small_raise"
    if amount_to_call <= 4.0 * bb:
        return "standard_raise"
    if amount_to_call <= 7.0 * bb:
        return "large_raise"
    return "huge_raise"

DEFEND_WIDTH_OPEN = {
    "min_raise": 0.80, "small_raise": 0.55, "large_raise": 0.22, "huge_raise": 0.12,
}
DEFEND_WIDTH_3BET = {
    "min_raise": 0.30, "small_raise": 0.20, "large_raise": 0.09, "huge_raise": 0.055,
}
POS_DEFEND_FACTOR = {"BB": 1.0, "SB": 0.80, "BTN": 0.70, "CO": 0.62, "HJ": 0.52, "UTG": 0.45}

def size_aware_open_defense(pos, steal, bucket, hand):
    base_3bet = (BLIND_DEFEND_3BET if steal else VS_OPEN_3BET).get(pos, set())
    base_call = (BLIND_DEFEND_CALL if steal else VS_OPEN_CALL).get(pos, set())
    threebet = base_3bet
    if bucket in ("min_raise", "small_raise"):

        width = DEFEND_WIDTH_OPEN[bucket] * POS_DEFEND_FACTOR.get(pos, 0.6)
        call = (base_call | base_3bet | defend_top(width)) - threebet
    else:

        call = base_call
    if hand in threebet:
        return "raise"
    if hand in call:
        return "call"
    return "fold"

def size_aware_3bet_defense(pos, bucket, hand):
    base_4bet = VS_3BET_4BET.get(pos, set())
    base_call = VS_3BET_CALL.get(pos, set())
    fourbet = base_4bet
    if bucket in ("min_raise", "small_raise"):
        width = DEFEND_WIDTH_3BET[bucket] * POS_DEFEND_FACTOR.get(pos, 0.6)
        call = (base_call | base_4bet | defend_top(width)) - fourbet
    else:
        call = base_call
    if hand in fourbet:
        return "4bet"
    if hand in call:
        return "call"
    return "fold"

def hand_class(cards):
    r0, r1 = cards[0][0], cards[1][0]
    if r0 == r1:
        return r0 + r1
    if RANK_VAL[r0] < RANK_VAL[r1]:
        r0, r1 = r1, r0
    suited = cards[0][1] == cards[1][1]
    return r0 + r1 + ("s" if suited else "o")

def get_positions(state):
    players = state.get("players", []) or []
    n = len(players)
    sb = bb = None
    for e in state.get("action_log", []) or []:
        if e.get("action") == "small_blind":
            sb = e.get("seat")
        elif e.get("action") == "big_blind":
            bb = e.get("seat")
    if sb is None or bb is None or n == 0:
        return 0, max(n, 2), 0, min(1, max(n - 1, 0))
    button = sb if n == 2 else (sb - 1) % n
    return button, n, sb, bb

def position_label(seat, button, n):
    rel = (seat - button) % n
    if n == 2:
        return "SB" if rel == 0 else "BB"
    if rel == 0:
        return "BTN"
    if rel == 1:
        return "SB"
    if rel == 2:
        return "BB"
    if rel == n - 1:
        return "CO"
    if rel == 3:
        return "UTG"
    return "HJ"

def preflop_context(state):
    raises = 0
    last_raiser = None
    bb_amt = DEFAULT_BB
    limpers = 0
    for e in state.get("action_log", []) or []:
        a = e.get("action")
        if a == "big_blind":
            bb_amt = e.get("amount") or DEFAULT_BB
        elif a in ("raise", "all_in"):
            raises += 1
            last_raiser = e.get("seat")
        elif a == "call" and raises == 0:
            limpers += 1
    return raises, last_raiser, bb_amt, limpers

def _is_in_position(hero_rel, villain_rel, n):
    def order(rel):
        return rel - 1 if rel >= 1 else n - 1
    return order(hero_rel) > order(villain_rel)

def open_size(state, bb_amt, n_limpers):
    to = int(2.5 * bb_amt) + bb_amt * n_limpers
    return max(to, state.get("min_raise_to", to))

def threebet_size(state, ip):
    cur = state.get("current_bet", DEFAULT_BB)
    return max(int(cur * (3.0 if ip else 4.0)), state.get("min_raise_to", cur))

def fourbet_size(state):
    cur = state.get("current_bet", DEFAULT_BB)
    return max(int(cur * 2.3), state.get("min_raise_to", cur))

def hu_preflop_decision(state, p, pos, raises, bb_amt, eff_bb):
    hand = hand_class(p["cards"])
    can_check = p["can_check"]

    if eff_bb <= SHORT_STACK_BB:
        if raises == 0:
            if pos == "SB":
                return {"action": "all_in"} if hand in defend_top(HU_JAM_SB_FRAC) \
                    else ({"action": "check"} if can_check else {"action": "fold"})
            if can_check:
                return {"action": "all_in"} if hand in defend_top(0.50) else {"action": "check"}
            return {"action": "fold"}
        return {"action": "all_in"} if hand in defend_top(HU_JAM_DEF_FRAC) \
            else ({"action": "check"} if can_check else {"action": "fold"})

    if raises == 0:
        if pos == "SB":
            if hand in defend_top(HU_SB_OPEN_FRAC):
                return {"action": "raise", "amount": open_size(state, bb_amt, 0)}
            return {"action": "check"} if can_check else {"action": "fold"}
        if can_check:
            if hand in defend_top(HU_BB_ISO_FRAC):
                return {"action": "raise", "amount": open_size(state, bb_amt, 1)}
            return {"action": "check"}
        return {"action": "fold"}

    if raises == 1:
        bucket = classify_raise_size(p["owed"], bb_amt)
        if hand in HU_BB_3BET:
            return {"action": "raise", "amount": threebet_size(state, pos == "SB")}
        frac = HU_BB_DEFEND_FRAC
        if bucket in ("min_raise", "small_raise"):
            frac = min(0.95, frac + 0.20)
        elif bucket in ("large_raise", "huge_raise"):
            frac = frac * 0.60
        if hand in defend_top(frac):
            return {"action": "call"}
        return {"action": "check"} if can_check else {"action": "fold"}

    if raises == 2:
        bucket = classify_raise_size(p["owed"], bb_amt)
        if hand in HU_SB_4BET:
            return {"action": "raise", "amount": fourbet_size(state)}
        callset = HU_SB_VS_3BET_CALL
        if bucket in ("min_raise", "small_raise"):
            callset = callset | defend_top(0.28)
        elif bucket in ("large_raise", "huge_raise"):
            callset = callset & defend_top(0.12)
        if hand in callset:
            return {"action": "call"}
        return {"action": "check"} if can_check else {"action": "fold"}

    if hand in HU_5BET_CONT:
        if eff_bb > 30 and hand == "AKs":
            return {"action": "call"}
        return {"action": "all_in"}
    return {"action": "check"} if can_check else {"action": "fold"}

def preflop_decision(state, p):
    cards = p["cards"]
    hand = hand_class(cards)
    button, n, sb, bb = get_positions(state)
    pos = position_label(p["seat"], button, n)
    raises, last_raiser, bb_amt, n_limpers = preflop_context(state)
    eff_bb = p["stack"] / bb_amt if bb_amt else 100

    if len(cards) == 2 and _preflop_facing_allin(state):
        n_opp = max(1, _n_live_opponents(state))
        return preflop_allin_equity_decision(state, p, n_opp)

    if n == 2:
        return hu_preflop_decision(state, p, pos, raises, bb_amt, eff_bb)

    if eff_bb <= SHORT_STACK_BB:
        if raises == 0:
            if pos == "BB" and p["can_check"]:
                return {"action": "all_in"} if hand in JAM_FIRST_IN.get("BB", set()) else {"action": "check"}
            if hand in JAM_FIRST_IN.get(pos, set()):
                return {"action": "all_in"}
            return {"action": "check"} if p["can_check"] else {"action": "fold"}
        if hand in JAM_VS_RAISE:
            return {"action": "all_in"}
        return {"action": "check"} if p["can_check"] else {"action": "fold"}

    if raises == 0:
        if pos == "BB" and p["can_check"]:
            if hand in OPEN["BB"]:
                return {"action": "raise", "amount": open_size(state, bb_amt, n_limpers)}
            return {"action": "check"}
        if hand in OPEN.get(pos, set()):
            return {"action": "raise", "amount": open_size(state, bb_amt, n_limpers)}

        if pos in ("SB", "BTN", "CO", "HJ"):
            fr = opponents_fold_read(state)
            if fr is not None and fr > 0.6:
                extra = min(0.45, (fr - 0.6) * 2.0)
                base_pct = len(OPEN.get(pos, ())) / float(N_HANDS)
                if hand in defend_top(min(0.95, base_pct + extra)):
                    return {"action": "raise", "amount": open_size(state, bb_amt, n_limpers)}
        return {"action": "check"} if p["can_check"] else {"action": "fold"}

    if raises == 1:
        villain_pos = position_label(last_raiser, button, n) if last_raiser is not None else "CO"
        steal = pos in ("SB", "BB") and villain_pos in ("CO", "BTN", "SB")
        bucket = classify_raise_size(p["owed"], bb_amt)
        action = size_aware_open_defense(pos, steal, bucket, hand)
        if action == "raise":
            hero_rel = (p["seat"] - button) % n
            vill_rel = (last_raiser - button) % n if last_raiser is not None else 0
            return {"action": "raise", "amount": threebet_size(state, _is_in_position(hero_rel, vill_rel, n))}
        if action == "call":
            return {"action": "call"}
        return {"action": "check"} if p["can_check"] else {"action": "fold"}

    if raises == 2:
        bucket = classify_raise_size(p["owed"], bb_amt)
        action = size_aware_3bet_defense(pos, bucket, hand)
        if action == "4bet":
            return {"action": "raise", "amount": fourbet_size(state)}
        if action == "call":
            return {"action": "call"}
        return {"action": "check"} if p["can_check"] else {"action": "fold"}

    bucket = classify_raise_size(p["owed"], bb_amt)
    cont = VS_4BET_CONT | R("QQ, AKo") if bucket in ("min_raise", "small_raise") else VS_4BET_CONT
    if hand in cont:
        if eff_bb > 30 and hand == "AKs" and bucket not in ("min_raise", "small_raise"):
            return {"action": "call"}
        return {"action": "all_in"}
    return {"action": "check"} if p["can_check"] else {"action": "fold"}

def _vals(cards):
    return [RANK_VAL[c[0]] for c in cards]

def _has_straight(valset):
    lo = -1 if 12 in valset else 0
    for start in range(lo, 9):
        if all((start + i if start + i >= 0 else 12) in valset or (start + i) in valset
               for i in range(5)):

            seq = set()
            for i in range(5):
                v = start + i
                seq.add(12 if v < 0 else v)
            if seq <= valset:
                return True
    return False

def _straight_completions(valset):
    present = set(valset)
    if 12 in present:
        present.add(-1)
    comps = set()
    for d in range(-1, 13):
        if d in present:
            continue
        s = set(present)
        s.add(d)

        for start in range(-1, 9):
            if all((start + i) in s for i in range(5)):
                comps.add(d if d >= 0 else 12)
                break
    return len(comps)

def hand_strength_bucket(hole, board):
    score = eval7.evaluate([eval7.Card(c) for c in hole + board])
    ht = str(eval7.handtype(score))
    if ht in ("Full House", "Quads", "Straight Flush"):
        return "full_house_or_better"
    if ht == "Flush":
        return "flush"
    if ht == "Straight":
        return "straight"
    if ht == "Trips":
        return "set_or_trips"
    if ht == "Two Pair":
        return "two_pair"
    if ht == "Pair":
        board_vals = sorted(set(_vals(board)), reverse=True)
        h0, h1 = hole[0][0], hole[1][0]
        v0, v1 = RANK_VAL[h0], RANK_VAL[h1]
        top = board_vals[0]
        if h0 == h1:
            if v0 > top:
                return "overpair"
            return "third_pair_or_underpair"

        paired_val = v0 if v0 in _vals(board) else (v1 if v1 in _vals(board) else None)
        kicker_val = v1 if paired_val == v0 else v0
        if paired_val is None:
            return "weak_showdown"
        rank_idx = board_vals.index(paired_val) if paired_val in board_vals else 99
        if rank_idx == 0:
            return "strong_top_pair" if kicker_val >= RANK_VAL["T"] else "weak_top_pair"
        if rank_idx == 1:
            return "second_pair"
        return "third_pair_or_underpair"

    board_top = max(_vals(board))
    overcards = sum(1 for c in hole if RANK_VAL[c[0]] > board_top)
    if overcards >= 2 or any(c[0] == "A" for c in hole):
        return "weak_showdown"
    return "air"

def board_texture_bucket(board):
    vals = _vals(board)
    suits = [c[1] for c in board]
    distinct = sorted(set(vals))
    top = max(vals)
    suit_counts = {}
    for s in suits:
        suit_counts[s] = suit_counts.get(s, 0) + 1
    maxsuit = max(suit_counts.values())
    has_pair = len(vals) != len(set(vals))

    if len(board) >= 4 and _has_straight(set(vals)):
        return "draw_completed"
    if maxsuit >= 3:
        return "monotone"
    if has_pair:
        return "paired"
    span = max(distinct) - min(distinct) if len(distinct) > 1 else 0
    connected = span <= 4 and len(distinct) >= 3
    allbroadway = all(v >= RANK_VAL["T"] for v in vals)
    if allbroadway and connected:
        return "broadway_connected"
    if connected and top <= RANK_VAL["9"]:
        return "low_connected"
    if connected:
        return "connected"
    if maxsuit == 2:
        return "two_tone"
    if top == RANK_VAL["A"]:
        return "A_high_dry"
    if top == RANK_VAL["K"]:
        return "K_high_dry"
    return "disconnected_low"

def draw_bucket(hole, board):
    if len(board) >= 5:
        return "no_draw"
    combined = hole + board
    suit_counts = {}
    for c in combined:
        suit_counts[c[1]] = suit_counts.get(c[1], 0) + 1
    flush4 = any(v == 4 for v in suit_counts.values())
    nut_flush = False
    if flush4:
        fs = [s for s, v in suit_counts.items() if v == 4][0]
        nut_flush = any(c[0] == "A" and c[1] == fs for c in hole)

    valset = set(RANK_VAL[c[0]] for c in combined)
    comps = _straight_completions(valset)
    oesd = comps >= 2
    gutshot = comps == 1

    if flush4 and (oesd or gutshot):
        return "combo_draw"
    if nut_flush:
        return "nut_draw"
    if flush4:
        return "flush_draw"
    if oesd:
        return "OESD"
    if gutshot:
        return "gutshot"
    if len(board) == 3 and any(v == 3 for v in suit_counts.values()):
        return "backdoor"
    return "no_draw"

def spr_bucket(stack, pot):
    if pot <= 0:
        return "6-10"
    spr = stack / pot
    if spr < 1:
        return "<1"
    if spr < 3:
        return "1-3"
    if spr < 6:
        return "3-6"
    if spr < 10:
        return "6-10"
    return ">=10"

def postflop_position(state):
    button, n, sb, bb = get_positions(state)
    players = state.get("players", []) or []
    seat = state.get("seat_to_act", 0)
    active = [i for i, p in enumerate(players)
             if not p.get("is_folded") and p.get("state") != "busted"]
    if len(active) <= 1:
        return "IP"

    def order(s):
        rel = (s - button) % n
        return rel - 1 if rel >= 1 else n - 1

    mine = order(seat)
    others = [order(s) for s in active if s != seat]
    if all(mine > o for o in others):
        return "IP"
    if all(mine < o for o in others):
        return "OOP"
    return "sandwiched"

def _n_live_opponents(state):
    players = state.get("players", []) or []
    seat = state.get("seat_to_act", 0)
    n = 0
    for i, p in enumerate(players):
        if i == seat:
            continue
        if not p.get("is_folded") and p.get("state") != "busted":
            n += 1
    return n

def bucket_bet_size(bet_amount, pot_at_time):
    if pot_at_time <= 0:
        return "min_bet"
    ratio = bet_amount / pot_at_time
    if ratio < 0.20:
        return "tiny_bet"
    if ratio < 0.45:
        return "small_bet"
    if ratio < 0.80:
        return "medium_bet"
    if ratio < 1.20:
        return "pot_bet"
    if ratio < 2.00:
        return "overbet"
    return "huge_overbet"

_FACING_FROM_SIZE = {
    "min_bet": "facing_small", "tiny_bet": "facing_small", "small_bet": "facing_small",
    "medium_bet": "facing_half", "pot_bet": "facing_pot",
    "overbet": "facing_overbet", "huge_overbet": "facing_overbet",
}

def facing_bucket(state):
    if state.get("can_check"):
        return "checked_to"
    if state.get("your_bet_this_street", 0) > 0:
        return "facing_raise"
    owed = state.get("amount_owed", 0)
    pot = state.get("pot", 0)
    return _FACING_FROM_SIZE[bucket_bet_size(owed, max(pot - owed, 1))]

STRONG_MADE = {"two_pair", "set_or_trips", "straight", "flush",
               "full_house_or_better", "overpair"}
GOOD_MADE = {"strong_top_pair"}
MEDIUM_MADE = {"weak_top_pair", "second_pair"}
WEAK_MADE = {"third_pair_or_underpair", "weak_showdown"}
STRONG_DRAWS = {"flush_draw", "OESD", "combo_draw", "nut_draw"}
WEAK_DRAWS = {"gutshot", "backdoor"}

def river_value_respect(dist, state, p, hs, opp_id):
    if RIVER_FOLD <= 0 or state.get("street") not in ("turn", "river") or state.get("can_check"):
        return dist
    if hs in STRONG_MADE:
        return dist
    bluff = stat_mean(opp_id, "bluff_propensity") if opp_id else 0.35
    agg = stat_mean(opp_id, "aggression") if opp_id else 0.25
    if bluff > 0.45 or agg > 0.45:
        return dist
    owed = state.get("amount_owed", 0)
    pot = state.get("pot", 0)
    ratio = owed / max(pot - owed, 1)
    shift = RIVER_FOLD * min(1.0, ratio)
    d = dict(dist)
    if d.get("call", 0.0) > 0:
        mv = d["call"] * shift
        d["call"] -= mv
        d["fold"] = d.get("fold", 0.0) + mv
    return _norm(d)

def river_flush_blocker(hole, board, hand_bucket):
    if len(board) < 5 or hand_bucket in ("flush", "full_house_or_better"):
        return False
    suit_counts = {}
    for c in board:
        suit_counts[c[1]] = suit_counts.get(c[1], 0) + 1
    for suit, cnt in suit_counts.items():
        if cnt != 3:
            continue
        board_ranks = {c[0] for c in board if c[1] == suit}
        hole_ranks = {c[0] for c in hole if c[1] == suit}
        if len(hole_ranks) >= 2:
            continue
        if "A" not in board_ranks and "A" in hole_ranks:
            return True
        if "A" in board_ranks and "K" not in board_ranks and "K" in hole_ranks:
            return True
    return False

def river_blocker_adjust(dist, state, p, hs, facing, opp_id):
    if state.get("street") != "river":
        return dist
    if not river_flush_blocker(p["cards"], state.get("community_cards", []) or [], hs):
        return dist
    shift = 0.12
    d = dict(dist)
    bluff_candidate = hs not in STRONG_MADE and hs not in GOOD_MADE and hs not in MEDIUM_MADE
    if facing == "checked_to":
        if bluff_candidate:
            f = stat_mean(opp_id, "fold_to_bet") if opp_id else 0.5
            if opp_id is None or f >= 0.35:
                mv = shift * d.get("check", 0.0)
                d["bet_66"] = d.get("bet_66", 0.0) + mv
                d["check"] = d.get("check", 0.0) - mv
    else:
        if hs not in STRONG_MADE and d.get("fold", 0.0) > 0:
            mv = shift * d["fold"]
            d["fold"] -= mv
            d["call"] = d.get("call", 0.0) + mv
    return _norm(d)

def _norm(d):
    tot = sum(v for v in d.values() if v > 0)
    if tot <= 0:
        return {"check": 1.0} if "check" in d else {"fold": 1.0}
    return {k: v / tot for k, v in d.items() if v > 0}

def strategy_checked_to(hs, texture, draw, spr, pos):
    ip = pos == "IP"
    multiway = pos == "sandwiched"
    dry = texture in ("A_high_dry", "K_high_dry", "disconnected_low")

    if hs in STRONG_MADE:
        if spr == "<1":
            d = {"all_in": 0.35, "bet_100": 0.35, "bet_66": 0.2, "check": 0.1}
        else:
            d = {"bet_66": 0.5, "bet_100": 0.25, "bet_33": 0.1, "check": 0.15}
    elif hs in GOOD_MADE:
        d = {"bet_66": 0.5, "bet_33": 0.2, "check": 0.3}
    elif hs in MEDIUM_MADE:
        d = {"bet_33": 0.35, "check": 0.65}
    elif draw in STRONG_DRAWS:
        d = {"bet_66": 0.5, "bet_33": 0.1, "check": 0.4} if ip else {"bet_66": 0.4, "check": 0.6}
    elif draw in WEAK_DRAWS:
        d = {"bet_33": 0.25, "check": 0.75}
    elif hs == "weak_showdown":
        d = {"check": 0.9, "bet_33": 0.1}
    else:
        if ip and dry:
            d = {"bet_66": 0.35, "bet_33": 0.1, "check": 0.55}
        else:
            d = {"bet_33": 0.18, "check": 0.82}

    if multiway:
        shifted = {}
        moved = 0.0
        for k, v in d.items():
            if k.startswith("bet") or k == "all_in":
                shifted[k] = v * 0.4
                moved += v * 0.6
            else:
                shifted[k] = v
        shifted["check"] = shifted.get("check", 0.0) + moved
        d = shifted
    elif not ip:
        moved = 0.0
        for k in list(d.keys()):
            if k.startswith("bet"):
                moved += d[k] * 0.15
                d[k] *= 0.85
        d["check"] = d.get("check", 0.0) + moved
    return _norm(d)

def strategy_facing(hs, texture, draw, spr, pos, facing):
    pressure = {"facing_small": 0, "facing_half": 1, "facing_pot": 2,
                "facing_overbet": 3, "facing_raise": 3}.get(facing, 1)

    if hs in STRONG_MADE:
        d = {"raise_pot": 0.4, "raise_value": 0.2, "call": 0.4}
        if spr == "<1" or pressure >= 2:
            d = {"all_in": 0.3, "raise_pot": 0.25, "call": 0.45}
    elif hs in GOOD_MADE or hs == "overpair":
        base = {"call": 0.7, "raise_value": 0.15, "fold": 0.15}
        fold_bonus = 0.12 * pressure
        base["fold"] += fold_bonus
        base["call"] = max(0.0, base["call"] - fold_bonus)
        base["raise_value"] = max(0.0, base["raise_value"] - 0.03 * pressure)
        d = base
    elif hs in MEDIUM_MADE:
        if pressure <= 0:
            d = {"call": 0.75, "fold": 0.2, "raise_value": 0.05}
        elif pressure == 1:
            d = {"call": 0.62, "fold": 0.38}
        elif pressure == 2:
            d = {"call": 0.4, "fold": 0.6}
        else:
            d = {"call": 0.18, "fold": 0.82}
    elif draw in STRONG_DRAWS:
        if pressure <= 0:
            d = {"call": 0.5, "raise_pot": 0.3, "fold": 0.2}
        elif pressure == 1:
            d = {"call": 0.6, "raise_pot": 0.1, "fold": 0.3}
        elif pressure == 2:
            d = {"call": 0.5, "fold": 0.5}
        else:
            d = {"call": 0.35, "fold": 0.65}
    elif draw in WEAK_DRAWS or hs == "weak_showdown":
        if pressure <= 0:
            d = {"call": 0.45, "fold": 0.5, "raise_pot": 0.05}
        elif pressure == 1:
            d = {"call": 0.3, "fold": 0.7}
        else:
            d = {"call": 0.1, "fold": 0.9}
    else:
        if pressure <= 0:
            d = {"fold": 0.85, "raise_pot": 0.15}
        elif pressure == 1:
            d = {"fold": 0.92, "raise_pot": 0.08}
        else:
            d = {"fold": 1.0}

    if pos == "sandwiched":
        if "raise_pot" in d:
            d["call"] = d.get("call", 0.0) + d["raise_pot"] * 0.5
            d["fold"] = d.get("fold", 0.0) + d["raise_pot"] * 0.5
            d.pop("raise_pot")
        if "raise_value" in d:
            d["call"] = d.get("call", 0.0) + d["raise_value"]
            d.pop("raise_value")
    return _norm(d)

def lookup_strategy(infoset_key, components, facing):

    if infoset_key in POSTFLOP_STRATEGY_TABLE:
        return POSTFLOP_STRATEGY_TABLE[infoset_key]
    hs, texture, draw, spr, pos = components
    if facing == "checked_to":
        return strategy_checked_to(hs, texture, draw, spr, pos)
    return strategy_facing(hs, texture, draw, spr, pos, facing)

N_OPP_ADJUSTMENTS = {
    1: {"bluff_freq_mult": 1.0,  "size_mult": 1.0, "call_tighten": 0.00},
    2: {"bluff_freq_mult": 0.30, "size_mult": 1.0, "call_tighten": 0.15},
    3: {"bluff_freq_mult": 0.05, "size_mult": 1.0, "call_tighten": 0.30},
    4: {"bluff_freq_mult": 0.02, "size_mult": 1.0, "call_tighten": 0.45},
    5: {"bluff_freq_mult": 0.00, "size_mult": 1.0, "call_tighten": 0.55},
}

AGG_ACTIONS = ("bet_33", "bet_66", "bet_100", "bet_150", "raise_value",
               "raise_pot", "all_in")

def multiway_adjust(dist, n_opp, hs, draw, facing):
    if n_opp <= 1:
        return dist
    adj = N_OPP_ADJUSTMENTS[min(n_opp, 5)]
    bf = adj["bluff_freq_mult"]
    is_value = hs in STRONG_MADE or hs in GOOD_MADE
    strong_draw = draw in STRONG_DRAWS
    d = dict(dist)

    if not is_value and not strong_draw:
        moved = 0.0
        for k in list(d):
            if k in AGG_ACTIONS:
                keep = d[k] * bf
                moved += d[k] - keep
                d[k] = keep
        passive = "check" if facing == "checked_to" else "fold"
        d[passive] = d.get(passive, 0.0) + moved

    if facing != "checked_to" and not is_value and "call" in d:
        if hs in MEDIUM_MADE or hs == "weak_showdown" or draw in WEAK_DRAWS or hs == "air":
            shift = min(d["call"], adj["call_tighten"])
            d["call"] -= shift
            d["fold"] = d.get("fold", 0.0) + shift

    return _norm(d)

OPPONENT_STATS = {}
PROCESSED_HANDS = set()

PRIORS = {
    "fold_to_bet":      (4.5, 5.5),
    "aggression":       (2.5, 7.5),
    "shove_frequency":  (0.3, 9.7),
    "bluff_propensity": (3.0, 7.0),
}
MIN_OBS = 10
LAMBDA_CAP = 0.30

def parse_hand_num(hand_id):
    if not hand_id:
        return None
    m = re.search(r"h(\d+)$", str(hand_id))
    return int(m.group(1)) if m else None

def aggression_modifier(state):
    hn = parse_hand_num(state.get("hand_id", ""))
    if hn is None or (HANDS_PER_MATCH - hn) > 50:
        return 1.0
    delta_ratio = state.get("your_stack", 0) / 10000.0
    if delta_ratio < 0.5:
        return 1.05
    if delta_ratio < 0.8:
        return 1.02
    if delta_ratio > 2.0:
        return 0.97
    if delta_ratio > 1.5:
        return 0.99
    return 1.0

def apply_aggression_modifier(dist, state):
    m = aggression_modifier(state)
    if m == 1.0:
        return dist
    d = dict(dist)
    for k in list(d):
        if k.startswith("bet") or k.startswith("raise") or k == "all_in":
            d[k] *= m
    return _norm(d)

def _ensure(bot_id):
    if bot_id not in OPPONENT_STATS:
        OPPONENT_STATS[bot_id] = {k: [a, b] for k, (a, b) in PRIORS.items()}
    return OPPONENT_STATS[bot_id]

def update_stat(bot_id, stat, success):
    s = _ensure(bot_id)[stat]
    if success:
        s[0] += 1
    else:
        s[1] += 1

def _ab(bot_id, stat):
    if bot_id in OPPONENT_STATS:
        a, b = OPPONENT_STATS[bot_id][stat]
    else:
        a, b = PRIORS[stat]
    return a, b

def stat_mean(bot_id, stat):
    a, b = _ab(bot_id, stat)
    return a / (a + b) if (a + b) else 0.5

def wilson_ci(a, b):
    n = a + b
    if n <= 0:
        return 0.5, 0.0, 1.0
    mean = a / n
    se = math.sqrt(max(mean * (1.0 - mean), 0.0) / n)
    half = 1.645 * se
    return mean, max(0.0, mean - half), min(1.0, mean + half)

def process_hand_actions(entries):
    by_bot = {}
    for e in entries:
        bid, act = e.get("bot_id"), e.get("action")
        if bid is None or act is None:
            continue
        by_bot.setdefault(bid, []).append(act)
    for bid, acts in by_bot.items():
        had_agg = False
        gave_up = False
        for act in acts:
            update_stat(bid, "aggression", act in ("raise", "all_in"))
            update_stat(bid, "shove_frequency", act == "all_in")
            if act == "fold":
                update_stat(bid, "fold_to_bet", True)
            elif act == "call":
                update_stat(bid, "fold_to_bet", False)
            if act in ("raise", "all_in"):
                had_agg = True
            elif act == "fold" and had_agg:
                gave_up = True
        if had_agg:
            update_stat(bid, "bluff_propensity", gave_up)

def update_opponent_memory(state):
    cur = parse_hand_num(state.get("hand_id", ""))
    if cur is None:
        return
    by_hand = {}
    for e in state.get("match_action_log", []) or []:
        hn = e.get("hand_num")
        if hn is None or hn == cur or hn in PROCESSED_HANDS:
            continue
        by_hand.setdefault(hn, []).append(e)
    for hn in sorted(by_hand):
        process_hand_actions(by_hand[hn])
        PROCESSED_HANDS.add(hn)

def compute_lambda(opp_id):
    if opp_id is None or opp_id not in OPPONENT_STATS:
        return 0.0
    a, b = OPPONENT_STATS[opp_id]["aggression"]
    n_obs = (a + b) - sum(PRIORS["aggression"])
    if n_obs < MIN_OBS:
        return 0.0
    data_factor = min(1.0, (n_obs - MIN_OBS) / 40.0)
    fa, fb = OPPONENT_STATS[opp_id]["fold_to_bet"]
    _, lo, hi = wilson_ci(fa, fb)
    conf = max(0.0, 1.0 - (hi - lo))
    return min(LAMBDA_CAP, LAMBDA_CAP * data_factor * (0.5 + 0.5 * conf))

def relevant_opponent_id(state):
    players = state.get("players", []) or []
    seat = state.get("seat_to_act", 0)
    if not state.get("can_check"):
        for e in reversed(state.get("action_log", []) or []):
            if e.get("action") in ("raise", "all_in") and e.get("seat") != seat:
                s = e.get("seat")
                if isinstance(s, int) and 0 <= s < len(players):
                    return players[s].get("bot_id")
    live = [i for i, pl in enumerate(players)
            if i != seat and not pl.get("is_folded") and pl.get("state") != "busted"]
    if len(live) == 1:
        return players[live[0]].get("bot_id")
    return None

def perturb_postflop(dist, opp_id, facing, hs, draw, n_opp):
    lam = compute_lambda(opp_id)
    if lam <= 0:
        return dist
    f = stat_mean(opp_id, "fold_to_bet")
    agg = stat_mean(opp_id, "aggression")
    bluff = stat_mean(opp_id, "bluff_propensity")
    d = dict(dist)

    value_ish = hs in STRONG_MADE or hs in GOOD_MADE or hs in MEDIUM_MADE
    bluff_ish = (not value_ish) and (draw not in STRONG_DRAWS)
    bet_keys = [k for k in d if k.startswith("bet") or k == "all_in"]

    if facing == "checked_to":
        if n_opp > 1:
            return dist
        if bluff_ish:
            if f > 0.55:
                move = lam * (f - 0.55) * 2.0 * d.get("check", 0.0)
                d["bet_66"] = d.get("bet_66", 0.0) + move
                d["check"] = d.get("check", 0.0) - move
            elif f < 0.35:
                frac = min(1.0, lam * (0.35 - f) * 2.5)
                moved = 0.0
                for k in bet_keys:
                    moved += d[k] * frac
                    d[k] *= (1.0 - frac)
                d["check"] = d.get("check", 0.0) + moved
        else:
            if f < 0.40:
                move = lam * (0.40 - f) * 2.0 * d.get("check", 0.0)
                d["bet_66"] = d.get("bet_66", 0.0) + move
                d["check"] = max(0.0, d.get("check", 0.0) - move)
                up = min(0.6, lam * (0.40 - f) * 2.0)
                for small, big in (("bet_33", "bet_66"), ("bet_66", "bet_100"),
                                   ("bet_100", "bet_150")):
                    if d.get(small, 0.0) > 0:
                        mv = d[small] * up
                        d[small] -= mv
                        d[big] = d.get(big, 0.0) + mv
    else:

        if "fold" in d and (agg > 0.40 or bluff > 0.45):
            g = min(0.8, lam * max((agg - 0.40) * 2.0, (bluff - 0.45) * 2.0))
            move = d["fold"] * g
            d["fold"] -= move
            d["call"] = d.get("call", 0.0) + move
    return _norm(d)

def opponents_fold_read(state):
    players = state.get("players", []) or []
    seat = state.get("seat_to_act", 0)
    reads = []
    for i, pl in enumerate(players):
        if i == seat or pl.get("is_folded") or pl.get("state") == "busted":
            continue
        bid = pl.get("bot_id")
        if bid and bid in OPPONENT_STATS and compute_lambda(bid) > 0:
            reads.append(stat_mean(bid, "fold_to_bet"))
    if not reads:
        return None
    return sum(reads) / len(reads)

_DECK_STR = [r + s for r in "23456789TJQKA" for s in "shdc"]
_DECK = [eval7.Card(s) for s in _DECK_STR]
PREFLOP_EQ = {}
_EQ_DEADLINE = 0.0
_RNG = random
EQ_BUDGET = 0.45
EQ_CALL_CAP = 0.15

def _now():
    return time.time()

def _canonical_hole(cls):
    if len(cls) == 2:
        return [cls[0] + "s", cls[1] + "h"]
    hi, lo, suit = cls[0], cls[1], cls[2]
    return [hi + "s", lo + "s"] if suit == "s" else [hi + "s", lo + "h"]

_EQUITY_TABLES = None
_TABLE_HAND_IDX = None
_TABLE_TEX_IDX = None
_TABLE_HS_IDX = None
_TABLE_FIRE_COUNTS = {"preflop_hit": 0, "postflop_hit": 0, "miss": 0}

def _load_equity_tables():
    global _EQUITY_TABLES, _TABLE_HAND_IDX, _TABLE_TEX_IDX, _TABLE_HS_IDX
    if not _NUMPY_OK:
        return False
    data_dir = os.environ.get(
        "BOT_DATA_DIR",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
    path = os.path.join(data_dir, "equity_tables.npz")
    try:
        d = np.load(path, allow_pickle=False)
        tables = {}
        for k in ("preflop_hand_vs_hand", "preflop_vs_random",
                  "postflop_class_n_opp", "postflop_class_filled",
                  "range_vs_range", "range_vs_range_filled"):
            if k in d.files:
                tables[k] = d[k]
        hand_classes = list(d["hand_classes"]) if "hand_classes" in d.files else None
        textures = list(d["board_textures"]) if "board_textures" in d.files else None
        strengths = list(d["hand_strengths"]) if "hand_strengths" in d.files else None
        if not tables or not hand_classes:
            return False
        _EQUITY_TABLES = tables
        _TABLE_HAND_IDX = {str(c): i for i, c in enumerate(hand_classes)}
        if textures:
            _TABLE_TEX_IDX = {str(t): i for i, t in enumerate(textures)}
        if strengths:
            _TABLE_HS_IDX = {str(h): i for i, h in enumerate(strengths)}
        return True
    except Exception:
        return False

_TABLES_LOADED = _load_equity_tables()

def lookup_preflop_vs_random(cls, n_opp):
    if not _TABLES_LOADED or _TABLE_HAND_IDX is None:
        return None
    t = _EQUITY_TABLES.get("preflop_vs_random")
    if t is None:
        return None
    idx = _TABLE_HAND_IDX.get(cls)
    if idx is None:
        return None
    n_clamped = max(1, min(5, n_opp))
    try:
        return float(t[idx, n_clamped - 1])
    except Exception:
        return None

def lookup_preflop_hand_vs_hand(cls_a, cls_b):
    if not _TABLES_LOADED or _TABLE_HAND_IDX is None:
        return None
    t = _EQUITY_TABLES.get("preflop_hand_vs_hand")
    if t is None:
        return None
    ia = _TABLE_HAND_IDX.get(cls_a); ib = _TABLE_HAND_IDX.get(cls_b)
    if ia is None or ib is None:
        return None
    try:
        return float(t[ia, ib])
    except Exception:
        return None

def lookup_postflop_class(texture, strength, n_opp):
    if not _TABLES_LOADED or _TABLE_TEX_IDX is None or _TABLE_HS_IDX is None:
        return None
    t = _EQUITY_TABLES.get("postflop_class_n_opp")
    f = _EQUITY_TABLES.get("postflop_class_filled")
    if t is None:
        return None
    ti = _TABLE_TEX_IDX.get(texture); hi = _TABLE_HS_IDX.get(strength)
    if ti is None or hi is None:
        return None
    if f is not None and int(f[ti, hi]) == 0:
        return None
    n_clamped = max(1, min(5, n_opp))
    try:
        v = float(t[ti, hi, n_clamped - 1])
        if v <= 0.0 or v >= 1.0:
            return None
        return v
    except Exception:
        return None

CRITICAL_EQ_BUDGET_S = 1.5
CRITICAL_MAX_ROLL = 50_000
CRITICAL_HARD_CAP_S = 1.7
_CRIT_EQ_FIRE_COUNT = 0

def critical_decision_equity(state, hole, board, n_opp, k_will_fire=False):
    global _CRIT_EQ_FIRE_COUNT
    try:
        pot = int(state.get("pot", 0) or 0)
        owed = int(state.get("amount_owed", 0) or 0)
        stack = int(state.get("your_stack", 0) or 0)
        street = state.get("street") or ""
        is_critical = (
            pot >= 3000
            or (stack > 0 and owed >= stack * 0.30)
            or street == "river"
        )
        if is_critical:
            _CRIT_EQ_FIRE_COUNT += 1

            if board and len(board) >= 3 and len(hole) == 2:
                try:
                    tex = board_texture_bucket(board)
                    hs = hand_strength_bucket(hole, board)
                    cached = lookup_postflop_class(tex, hs, n_opp)
                    if cached is not None:
                        _TABLE_FIRE_COUNTS["postflop_hit"] += 1

                        ref_deadline = min(_T0 + 1.0, _now() + 0.05)
                        refined = _equity_vs_random(
                            hole, board, n_opp, ref_deadline,
                            batch=200, max_roll=1500, ci_threshold=0.02)
                        return 0.70 * cached + 0.30 * refined
                except Exception:
                    pass

            if k_will_fire:

                crit_budget = 1.0
                ci_thresh = 0.008
            else:
                crit_budget = CRITICAL_EQ_BUDGET_S
                ci_thresh = 0.005

            crit_deadline = min(_T0 + crit_budget,
                                _T0 + CRITICAL_HARD_CAP_S - 0.05)

            if crit_deadline <= _now() + 0.05:
                return _equity_vs_random(
                    hole, board, n_opp,
                    min(_EQ_DEADLINE, _now() + EQ_CALL_CAP),
                    batch=300, max_roll=3000, ci_threshold=0.02)

            return _equity_vs_random(
                hole, board, n_opp, crit_deadline,
                batch=500, max_roll=CRITICAL_MAX_ROLL, ci_threshold=ci_thresh)
    except Exception:
        pass

    _TABLE_FIRE_COUNTS["miss"] += 1
    return _equity_vs_random(
        hole, board, n_opp,
        min(_EQ_DEADLINE, _now() + EQ_CALL_CAP),
        batch=300, max_roll=3000)

def _equity_vs_random(hole, board, n_opp, deadline, batch=300, max_roll=3000,
                       ci_threshold=0.02):
    try:
        hero = [eval7.Card(c) for c in hole]
        bd = [eval7.Card(c) for c in board]
    except Exception:
        return 0.5
    n_opp = max(1, min(8, n_opp))
    used = set(hole) | set(board)
    deck = [c for c, s in zip(_DECK, _DECK_STR) if s not in used]
    need = 5 - len(bd)
    take = n_opp * 2 + need
    if need < 0 or take > len(deck):
        return 0.5
    wins = 0.0
    n = 0
    while n < max_roll:
        for _ in range(batch):
            _RNG.shuffle(deck)
            full = bd + deck[n_opp * 2: n_opp * 2 + need]
            hv = eval7.evaluate(hero + full)
            best = -1
            for o in range(n_opp):
                ov = eval7.evaluate([deck[2 * o], deck[2 * o + 1]] + full)
                if ov > best:
                    best = ov
            if hv > best:
                wins += 1.0
            elif hv == best:
                wins += 0.5
            n += 1
        eq = wins / n
        half = 1.96 * math.sqrt(max(eq * (1.0 - eq), 1e-9) / n)
        if half < ci_threshold or _now() > deadline:
            break
    return wins / n if n else 0.5

def preflop_equity(cls, n_opp):
    n = max(1, min(5, n_opp))
    tbl = lookup_preflop_vs_random(cls, n)
    if tbl is not None:
        return tbl
    v = PREFLOP_EQ.get((cls, n))
    if v is not None:
        return v
    return _equity_vs_random(_canonical_hole(cls), [], n,
                             _now() + 0.05, batch=200, max_roll=800)

def precompute_preflop_equity(budget_s=2.0, max_opp=2):
    if _TABLES_LOADED and _EQUITY_TABLES.get("preflop_vs_random") is not None:
        for cls in HAND_RANK_ORDER:
            for n in range(1, 6):
                v = lookup_preflop_vs_random(cls, n)
                if v is not None:
                    PREFLOP_EQ[(cls, n)] = v
        return
    end = _now() + budget_s
    for cls in HAND_RANK_ORDER:
        if _now() > end:
            return
        hole = _canonical_hole(cls)
        for n in range(1, max_opp + 1):
            if (cls, n) in PREFLOP_EQ:
                continue
            PREFLOP_EQ[(cls, n)] = _equity_vs_random(
                hole, [], n, _now() + 0.03, batch=150, max_roll=450)

def _range_factor(opp_id, bet_ratio):
    base = 1.10 + 0.35 * min(max(bet_ratio, 0.0), 1.5)
    if opp_id is not None:
        agg = stat_mean(opp_id, "aggression")
        bluff = stat_mean(opp_id, "bluff_propensity")
        base -= 0.6 * max(agg - 0.30, 0.0) + 0.6 * max(bluff - 0.30, 0.0)
        base += 0.8 * max(0.20 - agg, 0.0)
    return max(0.70, min(1.70, base))

def apply_equity_facing(dist, state, p, hs, n_opp, opp_id):
    if state.get("can_check"):
        return dist
    pot = state.get("pot", 0)
    owed = state.get("amount_owed", 0)
    if owed <= 0:
        return dist
    risk = p["stack"] + state.get("your_bet_this_street", 0)
    commit = owed / (risk + 1) if risk > 0 else 1.0
    is_allin = any(pl.get("is_all_in") for pl in (state.get("players") or [])
                   if pl.get("seat") != state.get("seat_to_act"))
    if pot < 1200 and commit < 0.30 and not is_allin:
        return dist
    if _now() >= _EQ_DEADLINE and (state.get("pot", 0) < 3000 and state.get("street") != "river"):
        return dist

    eq = critical_decision_equity(state, p["cards"],
                                   state.get("community_cards", []),
                                   max(n_opp, 1))
    be = owed / (pot + owed)
    bet_ratio = owed / max(pot - owed, 1)
    req = be * _range_factor(opp_id, bet_ratio)
    if commit > 0.5:
        req += 0.03 * min(1.0, (commit - 0.5) * 2.0)
    d = dict(dist)
    margin = 0.04
    if is_allin:
        if eq >= req + margin and d.get("fold", 0.0) > 0:
            d["call"] = d.get("call", 0.0) + d["fold"]
            d["fold"] = 0.0
        elif eq < req - margin and d.get("call", 0.0) > 0:
            d["fold"] = d.get("fold", 0.0) + d["call"]
            d["call"] = 0.0
    else:
        if eq < req - margin and d.get("call", 0.0) > 0:
            d["fold"] = d.get("fold", 0.0) + d["call"]
            d["call"] = 0.0
    return _norm(d)

def multiway_value_verify(dist, state, p, hs, n_opp):
    if n_opp < 2 or state.get("pot", 0) < 1500:
        return dist
    if _now() >= _EQ_DEADLINE and state.get("pot", 0) < 3000:
        return dist

    eq = critical_decision_equity(state, p["cards"],
                                   state.get("community_cards", []), n_opp)
    fair = 1.0 / (n_opp + 1)
    d = dict(dist)
    if state.get("can_check"):
        if eq < fair * 1.25:
            for k in list(d):
                if k.startswith("bet") or k == "all_in":
                    d["check"] = d.get("check", 0.0) + d[k] * 0.6
                    d[k] *= 0.4
    else:
        if eq < fair * 1.10 and d.get("call", 0.0) > 0:
            d["fold"] = d.get("fold", 0.0) + d["call"] * 0.6
            d["call"] *= 0.4
    return _norm(d)

def _preflop_facing_allin(state):
    if state.get("can_check") or state.get("amount_owed", 0) <= 0:
        return False
    seat = state.get("seat_to_act")
    for pl in state.get("players", []) or []:
        if pl.get("seat") != seat and pl.get("is_all_in"):
            return True
    return False

PRE_AI_FOLD = float(os.environ.get("PRE_AI_FOLD", "0.15"))

def preflop_allin_equity_decision(state, p, n_opp):
    cls = hand_class(p["cards"])
    eq = preflop_equity(cls, max(n_opp, 1))
    pot, owed = p["pot"], p["owed"]
    be = owed / (pot + owed) if (pot + owed) > 0 else 1.0
    opp_id = relevant_opponent_id(state)
    shove = stat_mean(opp_id, "shove_frequency") if opp_id else 0.05
    agg = stat_mean(opp_id, "aggression") if opp_id else 0.25
    rf = (1.10 + PRE_AI_FOLD) - 1.5 * max(shove - 0.05, 0.0) - 0.4 * max(agg - 0.30, 0.0)
    rf = max(0.7, min(1.3 + PRE_AI_FOLD, rf))
    return {"action": "call"} if eq >= be * rf else \
        ({"action": "check"} if p["can_check"] else {"action": "fold"})

def _decision_seed(state):
    parts = [
        str(state.get("hand_id", "")),
        str(state.get("seat_to_act", "")),
        str(state.get("street", "")),
        str(len(state.get("action_log", []) or [])),
        str(state.get("pot", "")),
        str(state.get("current_bet", "")),
        str(state.get("amount_owed", "")),
        str(state.get("your_bet_this_street", "")),
    ]
    return int(hashlib.md5("|".join(parts).encode()).hexdigest()[:16], 16)

def sample_mixed_action(dist, state):
    if not dist:
        return None
    actions = sorted(dist.keys())
    probs = [max(0.0, dist[a]) for a in actions]
    total = sum(probs)
    if total <= 0:
        return actions[0]
    probs = [p / total for p in probs]
    rv = (_decision_seed(state) % 10**9) / 10**9
    c = 0.0
    for a, p in zip(actions, probs):
        c += p
        if rv < c:
            return a
    return actions[-1]

SIZE_MAP = {"bet_33": 0.29, "bet_66": 0.71, "bet_100": 1.13, "bet_150": 1.87}

def concrete_action(abstract, state, pot, owed, size_mult=1.0):
    cur = state.get("current_bet", 0)
    min_r = state.get("min_raise_to", 0)
    if abstract == "check":
        return {"action": "check"}
    if abstract == "call":
        return {"action": "call"}
    if abstract == "fold":
        return {"action": "fold"}
    if abstract == "all_in":
        return {"action": "all_in"}
    if abstract.startswith("bet_"):
        frac = SIZE_MAP[abstract]
        return {"action": "raise", "amount": max(int(frac * size_mult * pot), min_r)}
    if abstract == "raise_value":
        return {"action": "raise", "amount": max(int(cur * 2.5), min_r)}
    if abstract == "raise_pot":
        return {"action": "raise", "amount": max(cur + pot + owed, min_r)}
    return {"action": "check"} if state.get("can_check") else {"action": "fold"}

def postflop_decision(state, p):
    global POSTFLOP_DECISIONS, FALLBACK_DECISIONS
    POSTFLOP_DECISIONS += 1
    cards = p["cards"]
    board = state.get("community_cards", []) or []
    if len(cards) != 2 or len(board) < 3:
        FALLBACK_DECISIONS += 1
        return _simple_postflop(state, p)

    hs = hand_strength_bucket(cards, board)
    texture = board_texture_bucket(board)
    draw = draw_bucket(cards, board)
    spr = spr_bucket(p["stack"], max(state.get("pot", 1), 1))
    pos = postflop_position(state)
    facing = facing_bucket(state)

    key = "|".join((hs, texture, draw, spr, pos, facing))
    dist = lookup_strategy(key, (hs, texture, draw, spr, pos), facing)

    n_opp = _n_live_opponents(state)
    dist = multiway_adjust(dist, n_opp, hs, draw, facing)
    size_mult = N_OPP_ADJUSTMENTS[min(max(n_opp, 1), 5)]["size_mult"]

    opp_id = relevant_opponent_id(state)
    dist = perturb_postflop(dist, opp_id, facing, hs, draw, n_opp)

    dist = multiway_value_verify(dist, state, p, hs, n_opp)
    dist = apply_equity_facing(dist, state, p, hs, n_opp, opp_id)

    dist = river_blocker_adjust(dist, state, p, hs, facing, opp_id)

    dist = river_value_respect(dist, state, p, hs, opp_id)

    dist = apply_aggression_modifier(dist, state)

    abstract = sample_mixed_action(dist, state)
    return concrete_action(abstract, state, state.get("pot", 0),
                           state.get("amount_owed", 0), size_mult)

def _simple_postflop(state, p):
    if p["can_check"]:
        return {"action": "check"}
    if p["owed"] > 0 and p["pot"] / p["owed"] >= 3:
        return {"action": "call"}
    return {"action": "fold"}

_GOV_COUNTS = {"called": 0, "B": 0, "D": 0, "A": 0, "C": 0, "E": 0}

def _board_vals(board):
    return [RANK_VAL[c[0]] for c in board if c]

def _gov_is_paired_board(board):
    if len(board) < 2:
        return False
    vs = _board_vals(board)
    return len(vs) != len(set(vs))

def _gov_is_double_paired_board(board):
    if len(board) < 4:
        return False
    vs = _board_vals(board)
    counts = {}
    for v in vs:
        counts[v] = counts.get(v, 0) + 1
    return sum(1 for n in counts.values() if n >= 2) >= 2

def _gov_has_trips_on_board(board):
    if len(board) < 3:
        return False
    vs = _board_vals(board)
    counts = {}
    for v in vs:
        counts[v] = counts.get(v, 0) + 1
    return any(n >= 3 for n in counts.values())

def _gov_flush_completed(board):
    if len(board) < 5:
        return False
    suits = {}
    for c in board:
        suits[c[1]] = suits.get(c[1], 0) + 1
    return max(suits.values()) >= 5

def _gov_four_flush_board(board):
    if len(board) < 4:
        return False
    suits = {}
    for c in board:
        suits[c[1]] = suits.get(c[1], 0) + 1
    return max(suits.values()) >= 4

def _gov_one_card_straight_possible(board):
    if len(board) < 4:
        return False
    vs = sorted(set(_board_vals(board)))
    for i in range(len(vs) - 3):
        if vs[i + 3] - vs[i] <= 4:
            return True
    if 12 in vs and {0, 1, 2}.issubset(vs):
        return True
    return False

def _gov_board_very_wet(board):
    if len(board) < 3:
        return False
    bt = board_texture_bucket(board)
    return bt in ("monotone", "broadway_connected", "low_connected", "connected")

def _gov_last_agg_villain_seat(action_log, hero_seat):
    last = None
    for a in action_log or []:
        if a.get("seat") != hero_seat and a.get("action") in ("raise", "all_in"):
            last = a.get("seat")
    return last

def _gov_villain_check_raised(action_log, villain_seat):
    if villain_seat is None or not action_log:
        return False
    saw_check = False
    for a in action_log:
        if a.get("seat") == villain_seat:
            if a.get("action") == "check":
                saw_check = True
            elif a.get("action") in ("raise", "all_in") and saw_check:
                return True
    return False

def _gov_villain_2plus_raises(action_log, villain_seat):
    if villain_seat is None:
        return False
    return sum(1 for a in (action_log or [])
               if a.get("seat") == villain_seat
               and a.get("action") in ("raise", "all_in")) >= 2

def _gov_hero_has_nut_blocker(hole, board):
    if len(board) < 3 or len(hole) < 2:
        return False
    suits = {}
    for c in board:
        suits[c[1]] = suits.get(c[1], 0) + 1
    if not suits or max(suits.values()) < 3:
        return False
    flush_suit = max(suits, key=suits.get)
    return any(c[0] == "A" and c[1] == flush_suit for c in hole)

def _gov_hero_actual_nuts(hole, board, hand_class):
    if hand_class != "full_house_or_better":
        return False
    if not _gov_is_paired_board(board):
        return False
    return True

_RIO_INDEX = None
_RIO_FILLED = None
_RIO_HS_IDX = None
_RIO_TEX_IDX = None
_RIO_ST_IDX = None
_RIO_FIRED_COUNT = 0
_RIO_CHANGED_ACTION_COUNT = 0
_RIO_SUPPRESSED_K_COUNT = 0

_RIO_SPR_STR_TO_IDX = {"<1": 0, "1-3": 1, "3-6": 2, "6-10": 3, ">=10": 4}

def _load_rio_index():
    global _RIO_INDEX, _RIO_FILLED, _RIO_HS_IDX, _RIO_TEX_IDX, _RIO_ST_IDX
    if not _NUMPY_OK:
        return False
    data_dir = os.environ.get(
        "BOT_DATA_DIR",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "data"))
    path = os.path.join(data_dir, "rio_index.npz")
    try:
        d = np.load(path, allow_pickle=False)
        if "rio_index" not in d.files:
            return False
        _RIO_INDEX = d["rio_index"]
        _RIO_FILLED = d["filled"] if "filled" in d.files else None
        if "hand_strengths" in d.files:
            _RIO_HS_IDX = {str(s): i for i, s in enumerate(d["hand_strengths"])}
        if "board_textures" in d.files:
            _RIO_TEX_IDX = {str(s): i for i, s in enumerate(d["board_textures"])}
        if "streets" in d.files:
            _RIO_ST_IDX = {str(s): i for i, s in enumerate(d["streets"])}
        return True
    except Exception:
        return False

_RIO_LOADED = _load_rio_index()

def rio_lookup(hand_strength, board, street, spr_str):
    if not _RIO_LOADED or _RIO_INDEX is None or _RIO_HS_IDX is None:
        return None
    try:
        hs_i = _RIO_HS_IDX.get(hand_strength)
        tex = board_texture_bucket(board) if board else None
        tex_i = _RIO_TEX_IDX.get(tex) if tex and _RIO_TEX_IDX else None
        st_i = _RIO_ST_IDX.get(street) if street and _RIO_ST_IDX else None
        spr_i = _RIO_SPR_STR_TO_IDX.get(spr_str)
        if hs_i is None or tex_i is None or st_i is None or spr_i is None:
            return None

        if _RIO_FILLED is not None and int(_RIO_FILLED[hs_i, tex_i, st_i]) < 5:
            return None
        row = _RIO_INDEX[hs_i, tex_i, st_i, spr_i]
        return float(row[0]), float(row[1]), float(row[2])
    except Exception:
        return None

def _nut_danger_with_rio(state, hand_class, hand_strength=None):
    global _RIO_FIRED_COUNT
    base = nut_danger_score(state, hand_class)
    if not _RIO_LOADED:
        return base, base, None
    board = state.get("community_cards") or []
    if len(board) < 3:
        return base, base, None

    hole = state.get("your_cards") or []
    if hand_strength is None:
        if len(hole) != 2:
            return base, base, None
        try:
            hand_strength = hand_strength_bucket(hole, board)
        except Exception:
            return base, base, None
    street = state.get("street") or ""
    if street not in ("flop", "turn", "river"):
        return base, base, None
    stack = state.get("your_stack", 0) or 0
    pot = state.get("pot", 0) or 0
    spr_str = spr_bucket(stack, pot)
    rio = rio_lookup(hand_strength, board, street, spr_str)
    if rio is None:
        return base, base, None
    rio_score, _, _ = rio
    _RIO_FIRED_COUNT += 1

    amped = base + min(3.5, rio_score * 3.5)
    return amped, base, rio_score

def nut_danger_score(state, hand_class):
    board = state.get("community_cards") or []
    action_log = state.get("action_log") or []
    hero_seat = state.get("seat_to_act")
    hole = state.get("your_cards") or []
    s = 0
    if _gov_is_paired_board(board): s += 1
    if _gov_is_double_paired_board(board): s += 2
    if _gov_has_trips_on_board(board): s += 2
    if _gov_flush_completed(board): s += 1
    if _gov_four_flush_board(board): s += 2
    if _gov_one_card_straight_possible(board): s += 1
    if _gov_board_very_wet(board): s += 1
    villain = _gov_last_agg_villain_seat(action_log, hero_seat)
    if villain is not None:
        if _gov_villain_check_raised(action_log, villain): s += 2
        if _gov_villain_2plus_raises(action_log, villain): s += 2
    if _gov_hero_has_nut_blocker(hole, board): s -= 1
    if _gov_hero_actual_nuts(hole, board, hand_class): s -= 3
    if hand_class in ("straight", "flush", "full_house_or_better"):
        s -= 1
    if hand_class == "set_or_trips" and not _gov_has_trips_on_board(board) \
            and not _gov_is_double_paired_board(board):
        s -= 1
    return max(0, s)

def _gov_commit_fraction(state, action):
    stack = state.get("your_stack", 0) or 0
    already = state.get("your_bet_this_street", 0) or 0
    base = stack + already
    if base <= 0:
        return 0.0
    a = action.get("action")
    if a == "all_in":
        return 1.0
    if a == "raise":
        amt = action.get("amount", 0) or 0
        addl = max(0, amt - already)
        return min(1.0, addl / max(base, 1))
    if a == "call":
        owed = state.get("amount_owed", 0) or 0
        return min(1.0, owed / max(base, 1))
    return 0.0

def _gov_to_call_or_fold(state):
    if state.get("can_check"):
        return {"action": "check"}
    if (state.get("amount_owed", 0) or 0) > 0:
        return {"action": "call"}
    return {"action": "fold"}

def _gov_hero_class(state, p):
    hole = (p or {}).get("cards") or state.get("your_cards") or []
    board = state.get("community_cards") or []
    if len(hole) == 2 and len(board) >= 3:
        try:
            return hand_strength_bucket(hole, board)
        except Exception:
            return None
    return None

def _patch_B(state, action, hand_class):
    if action.get("action") not in ("raise", "all_in"):
        return action
    board = state.get("community_cards") or []
    if not board or hand_class is None:
        return action

    if hand_class in ("set_or_trips", "straight", "flush", "full_house_or_better",
                      "two_pair", "overpair", "strong_top_pair"):
        return action

    _GOV_COUNTS["B"] += 1
    return _gov_to_call_or_fold(state)

def _patch_D(state, action, hand_class):
    if action.get("action") not in ("raise", "all_in"):
        return action
    al = state.get("action_log") or []
    hero_seat = state.get("seat_to_act")
    villain = _gov_last_agg_villain_seat(al, hero_seat)
    if villain is None:
        return action
    villain_acts = [a.get("action") for a in al if a.get("seat") == villain]
    score = 0
    if "check" in villain_acts:
        idx = villain_acts.index("check")
        if any(x in ("raise", "all_in") for x in villain_acts[idx:]):
            score += 2
    if "call" in villain_acts and "raise" in villain_acts:
        cidx = villain_acts.index("call")
        if "raise" in villain_acts[cidx + 1:]:
            score += 1
    if score >= 3 and hand_class not in ("straight", "flush", "full_house_or_better"):
        _GOV_COUNTS["D"] += 1
        return _gov_to_call_or_fold(state)
    return action

def _patch_A(state, action, hand_class, opp_id):
    global _RIO_SUPPRESSED_K_COUNT
    cf = _gov_commit_fraction(state, action)
    if cf < 0.40:
        return action, False
    danger_rio, danger_base, rio_score = _nut_danger_with_rio(state, hand_class)
    bluff = stat_mean(opp_id, "bluff_propensity") if opp_id else 0.30
    if bluff > 0.50:
        danger_rio -= 1
        danger_base -= 1
    is_marginal_class = hand_class in (
        "weak_top_pair", "strong_top_pair", "overpair", "two_pair", "set_or_trips")
    veto_rio = danger_rio >= 2 and is_marginal_class
    veto_base = danger_base >= 2 and is_marginal_class
    if veto_rio:
        _GOV_COUNTS["A"] += 1
        if rio_score is not None and not veto_base:

            _RIO_SUPPRESSED_K_COUNT += 1
        return _gov_to_call_or_fold(state), True
    return action, False

_STACKOFF_BASE = {"flop": 0.62, "turn": 0.58, "river": 0.52}

def _patch_C(state, action, hand_class, equity_est):
    global _RIO_SUPPRESSED_K_COUNT
    cf = _gov_commit_fraction(state, action)
    if cf < 0.40:
        return action, False
    if equity_est is None:
        return action, False
    street = state.get("street") or "preflop"
    base = _STACKOFF_BASE.get(street, 0.60)
    danger_rio, danger_base, rio_score = _nut_danger_with_rio(state, hand_class)
    required_rio = min(0.85, base + 0.04 * danger_rio)
    required_base = min(0.85, base + 0.04 * danger_base)
    veto_rio = equity_est < required_rio
    veto_base = equity_est < required_base
    if veto_rio:
        _GOV_COUNTS["C"] += 1
        if rio_score is not None and not veto_base:
            _RIO_SUPPRESSED_K_COUNT += 1
        return _gov_to_call_or_fold(state), True
    return action, False

def _patch_E(state, action, opp_id, hand_class, vetoed):
    if vetoed:
        return action
    if (state.get("street") or "") != "river":
        return action
    if action.get("action") != "fold":
        return action
    bluff = stat_mean(opp_id, "bluff_propensity") if opp_id else 0.30
    if bluff < 0.30:
        return action
    hole = state.get("your_cards") or []
    board = state.get("community_cards") or []
    if not _gov_hero_has_nut_blocker(hole, board):
        return action
    if (state.get("amount_owed", 0) or 0) > 0:
        _GOV_COUNTS["E"] += 1
        return {"action": "call"}
    return action

K_TOTAL_BUDGET_S = 0.50
K_PER_CANDIDATE_OVERHEAD_S = 0.005
_K_FIRED_COUNT = 0
_K_TIMED_OUT_COUNT = 0
_K_CHANGED_ACTION_COUNT = 0

_K_GENERIC_RANGE_CACHE = None

def _k_generic_range():
    global _K_GENERIC_RANGE_CACHE
    if _K_GENERIC_RANGE_CACHE is None:
        try:
            _K_GENERIC_RANGE_CACHE = list(defend_top(0.30))
        except Exception:
            _K_GENERIC_RANGE_CACHE = []
    return _K_GENERIC_RANGE_CACHE

def _k_villain_range_classes(opp_id, board, action_log, hero_seat):
    base_pct = 0.30
    if opp_id:
        try:
            agg = stat_mean(opp_id, "aggression")
            bluff = stat_mean(opp_id, "bluff_propensity")

            base_pct = max(0.15, min(0.55, 0.30 + 0.3 * (agg - 0.30) + 0.2 * (bluff - 0.30)))
        except Exception:
            pass

    villain_seat = _gov_last_agg_villain_seat(action_log or [], hero_seat)
    if villain_seat is not None and villain_seat == _last_aggressive_seat_in_log(action_log or []):
        if _gov_villain_check_raised(action_log or [], villain_seat):
            base_pct = max(0.10, base_pct - 0.15)
        elif _gov_villain_2plus_raises(action_log or [], villain_seat):
            base_pct = max(0.12, base_pct - 0.10)
    try:
        return list(defend_top(base_pct))
    except Exception:
        return _k_generic_range()

def _last_aggressive_seat_in_log(action_log):
    last = None
    for a in action_log:
        if a.get("action") in ("raise", "all_in"):
            last = a.get("seat")
    return last

def _k_estimate_fold_prob(state, bet_amount, opp_id):
    pot = max(state.get("pot", 0) or 0, 1)
    base = 0.40
    if opp_id:
        try:
            f2b = stat_mean(opp_id, "fold_to_bet")
            base = max(0.05, min(0.95, f2b))
        except Exception:
            pass

    pressure_ratio = bet_amount / pot if pot > 0 else 1.0
    pressure_mult = 1.0 + 0.4 * max(0.0, min(1.5, pressure_ratio - 0.5))
    return max(0.02, min(0.95, base * pressure_mult))

_K_FULL_DECK = None
def _k_full_deck():
    global _K_FULL_DECK
    if _K_FULL_DECK is None:
        ranks = "23456789TJQKA"; suits = "shdc"
        _K_FULL_DECK = [r + s for r in ranks for s in suits]
    return _K_FULL_DECK

def _k_sample_villain_hole(range_classes, dead_cards, rng):
    if not range_classes:
        return None

    for _ in range(20):
        cls = range_classes[rng.randrange(len(range_classes))]
        try:
            hole = _canonical_hole(cls)
        except Exception:
            continue
        if hole[0] in dead_cards or hole[1] in dead_cards:
            continue
        return tuple(hole)
    return None

def _k_simulate_to_terminal(state, our_action, hero_cards, board, opp_id,
                              villain_range, rng):
    try:
        action = our_action.get("action")
        if action == "fold":
            return 0
        pot = state.get("pot", 0) or 0
        stack = state.get("your_stack", 0) or 0
        already = state.get("your_bet_this_street", 0) or 0
        if action == "all_in":
            bet_amount = stack
        elif action == "call":
            bet_amount = state.get("amount_owed", 0) or 0
        elif action == "raise":
            total = our_action.get("amount", 0) or 0
            bet_amount = max(0, total - already)
        else:
            return None

        bet_amount = max(0, min(bet_amount, stack))

        fold_prob = _k_estimate_fold_prob(state, bet_amount, opp_id)
        if rng.random() < fold_prob:
            return pot

        dead = set(hero_cards) | set(board)
        villain = _k_sample_villain_hole(villain_range, dead, rng)
        if villain is None:
            return None

        full_board = list(board)
        need = 5 - len(full_board)
        if need > 0:
            deck_dead = dead | set(villain)
            deck = [c for c in _k_full_deck() if c not in deck_dead]
            if len(deck) < need:
                return None

            picks = []
            while len(picks) < need:
                c = deck[rng.randrange(len(deck))]
                if c not in picks:
                    picks.append(c)
            full_board = full_board + picks

        hero_score = eval7.evaluate(
            [eval7.Card(c) for c in list(hero_cards) + full_board])
        villain_score = eval7.evaluate(
            [eval7.Card(c) for c in list(villain) + full_board])
        final_pot = pot + 2 * bet_amount
        if hero_score > villain_score:
            return final_pot - bet_amount
        if hero_score < villain_score:
            return -bet_amount
        return 0
    except Exception:
        return None

def _k_legal_raise_amount(state, fraction_of_pot):
    pot = max(state.get("pot", 0) or 0, 1)
    cur = state.get("current_bet", 0) or 0
    min_r = state.get("min_raise_to", 0) or 0
    your_bet = state.get("your_bet_this_street", 0) or 0
    max_r = (state.get("your_stack", 0) or 0) + your_bet
    target = cur + int(fraction_of_pot * pot)
    target = max(target, min_r)
    target = min(target, max_r)
    return target

def _k_build_candidate_actions(state, current_action):
    cand = []
    can_check = state.get("can_check", False)
    owed = state.get("amount_owed", 0) or 0
    your_bet = state.get("your_bet_this_street", 0) or 0
    stack = state.get("your_stack", 0) or 0
    min_r = state.get("min_raise_to", 0) or 0
    max_r = stack + your_bet

    if can_check:
        cand.append({"action": "check"})
    else:
        cand.append({"action": "fold"})

    if owed > 0:
        cand.append({"action": "call"})

    if min_r > your_bet and min_r <= max_r:
        small = _k_legal_raise_amount(state, 0.5)
        potraise = _k_legal_raise_amount(state, 1.0)
        if small > your_bet:
            cand.append({"action": "raise", "amount": small})
        if potraise > your_bet and potraise != small:
            cand.append({"action": "raise", "amount": potraise})

        if max_r > your_bet:
            cand.append({"action": "all_in"})

    seen, dedup = set(), []
    for a in cand:
        key = (a.get("action"), a.get("amount"))
        if key not in seen:
            seen.add(key); dedup.append(a)
    return dedup

def k_stack_off_ev_simulation(state, hero_cards, board, opp_id,
                                current_action, hero_seat):
    global _K_FIRED_COUNT, _K_TIMED_OUT_COUNT
    try:
        cf = _gov_commit_fraction(state, current_action)
        if cf < 0.40:
            return None
        candidates = _k_build_candidate_actions(state, current_action)
        if not candidates or len(candidates) < 2:
            return None
        _K_FIRED_COUNT += 1
        start = _now()

        k_deadline = min(start + K_TOTAL_BUDGET_S,
                         _T0 + CRITICAL_HARD_CAP_S - 0.02)
        if k_deadline <= start + 0.01:
            _K_TIMED_OUT_COUNT += 1
            return None
        per_cand_budget = (k_deadline - start) / max(len(candidates), 1)

        try:
            rng = random.Random(_decision_seed(state) ^ 0xABCDEF)
        except Exception:
            rng = random.Random()
        action_log = state.get("action_log") or []
        villain_range = _k_villain_range_classes(
            opp_id, board or [], action_log, hero_seat)
        candidate_evs = []
        timed_out = False
        for action in candidates:
            if _now() >= k_deadline:
                timed_out = True
                break
            cand_start = _now()
            cand_deadline = min(cand_start + per_cand_budget, k_deadline)
            ev_sum = 0.0
            n_sims = 0
            n_skipped = 0
            while n_sims < 5000:
                if _now() >= cand_deadline:
                    break
                outcome = _k_simulate_to_terminal(
                    state, action, hero_cards, board or [], opp_id,
                    villain_range, rng)
                if outcome is None:
                    n_skipped += 1
                    if n_skipped > 50:
                        break
                    continue
                ev_sum += outcome
                n_sims += 1
            if n_sims >= 50:
                candidate_evs.append((ev_sum / n_sims, action, n_sims))
        if timed_out:
            _K_TIMED_OUT_COUNT += 1
        if len(candidate_evs) < 2:
            return None

        candidate_evs.sort(key=lambda x: -x[0])
        best_ev, best_action, _ = candidate_evs[0]
        return best_action
    except Exception:
        return None

_V1510C_FIRED = 0
_V1510C_FIRED_LOG = []
_V1510C_FH_OR_BETTER = ("Full House", "Quads", "Straight Flush")

def _v1510c_river_creates_pair(board):
    if not board or len(board) != 5:
        return False
    pre_ranks = [c[0] for c in board[:4]]
    counts = {}
    for r in pre_ranks:
        counts[r] = counts.get(r, 0) + 1
    if counts and max(counts.values()) >= 2:
        return False
    return board[4][0] in pre_ranks

def _v1510c_hero_is_fh_or_better(hero_cards, board):
    try:
        if len(hero_cards) != 2 or len(board) != 5:
            return True
        score = eval7.evaluate([eval7.Card(c) for c in list(hero_cards) + list(board)])
        ht = str(eval7.handtype(score))
        return ht in _V1510C_FH_OR_BETTER
    except Exception:
        return True

def river_pair_transition_guard(state, intended_action, hero_cards, board):
    global _V1510C_FIRED
    try:
        if state.get("street") != "river":
            return intended_action
        if not _v1510c_river_creates_pair(board):
            return intended_action
        if _v1510c_hero_is_fh_or_better(hero_cards, board):
            return intended_action
        commit = _gov_commit_fraction(state, intended_action)
        if commit < 0.30:
            return intended_action
        action_type = intended_action.get("action")
        if action_type in ("raise", "bet", "all_in"):
            _V1510C_FIRED += 1
            if len(_V1510C_FIRED_LOG) < 50:
                _V1510C_FIRED_LOG.append({
                    "hand_id": state.get("hand_id"), "pot": state.get("pot", 0),
                    "hero_cards": list(hero_cards), "board": list(board),
                    "old": dict(intended_action),
                })
            can_check = state.get("can_check", False)
            new_action = {"action": "check"} if can_check else {"action": "call"}
            if _V1510C_FIRED_LOG:
                _V1510C_FIRED_LOG[-1]["new"] = dict(new_action)
            return new_action
        if action_type == "call":
            owed = state.get("amount_owed", 0) or 0
            pot = max(state.get("pot", 1) or 1, 1)
            if owed > 0.45 * pot:
                _V1510C_FIRED += 1
                if len(_V1510C_FIRED_LOG) < 50:
                    _V1510C_FIRED_LOG.append({
                        "hand_id": state.get("hand_id"), "pot": state.get("pot", 0),
                        "hero_cards": list(hero_cards), "board": list(board),
                        "old": dict(intended_action), "new": {"action": "fold"},
                    })
                return {"action": "fold"}
        return intended_action
    except Exception:
        return intended_action

_V1510D_FIRED = 0
_V1510D_FIRED_LOG = []
_V1510D_TRIPS_OR_BETTER = ("Trips", "Three of a Kind", "Straight", "Flush",
                            "Full House", "Quads", "Straight Flush")

def _v1510d_is_paired_board(board):
    if not board or len(board) < 5:
        return False
    ranks = [c[0] for c in board if c]
    counts = {}
    for r in ranks:
        counts[r] = counts.get(r, 0) + 1
    return max(counts.values()) >= 2 if counts else False

def _v1510d_multiway_active_at_river(action_log, n_players):
    if n_players <= 2:
        return False
    folded = set()
    for a in (action_log or []):
        if a.get("action") == "fold":
            folded.add(a.get("seat"))
    return (n_players - len(folded)) >= 3

def _v1510d_hero_trips_or_better(hero_cards, board):
    try:
        if len(hero_cards) != 2 or len(board) != 5:
            return True
        score = eval7.evaluate([eval7.Card(c) for c in list(hero_cards) + list(board)])
        ht = str(eval7.handtype(score))
        return ht in _V1510D_TRIPS_OR_BETTER
    except Exception:
        return True

def multiway_paired_river_supercap(state, intended_action, hero_cards, board,
                                     action_log, n_players):
    global _V1510D_FIRED
    try:
        if state.get("street") != "river":
            return intended_action
        if not _v1510d_is_paired_board(board):
            return intended_action
        if not _v1510d_multiway_active_at_river(action_log, n_players):
            return intended_action
        action_type = intended_action.get("action")
        if action_type not in ("raise", "bet", "all_in"):
            return intended_action
        if _v1510d_hero_trips_or_better(hero_cards, board):
            return intended_action
        _V1510D_FIRED += 1
        if len(_V1510D_FIRED_LOG) < 50:
            _V1510D_FIRED_LOG.append({
                "hand_id": state.get("hand_id"), "pot": state.get("pot", 0),
                "hero_cards": list(hero_cards), "board": list(board),
                "old": dict(intended_action),
            })
        can_check = state.get("can_check", False)
        new_action = {"action": "check"} if can_check else {"action": "call"}
        if _V1510D_FIRED_LOG:
            _V1510D_FIRED_LOG[-1]["new"] = dict(new_action)
        return new_action
    except Exception:
        return intended_action

def apply_governors(action, state, p):
    global _K_CHANGED_ACTION_COUNT
    try:
        _GOV_COUNTS["called"] += 1
        opp_id = relevant_opponent_id(state)
        hand_class = _gov_hero_class(state, p)

        will_k_fire = _gov_commit_fraction(state, action) >= 0.40
        eq = None
        if hand_class is not None and _gov_commit_fraction(state, action) >= 0.40:
            try:
                eq = critical_decision_equity(
                    state,
                    p.get("cards") or [],
                    state.get("community_cards") or [],
                    max(1, _n_live_opponents(state)),
                    k_will_fire=will_k_fire)
            except Exception:
                eq = None
        action = _patch_B(state, action, hand_class)
        action = _patch_D(state, action, hand_class)
        action, v_a = _patch_A(state, action, hand_class, opp_id)
        action, v_c = _patch_C(state, action, hand_class, eq)
        action = _patch_E(state, action, opp_id, hand_class, v_a or v_c)

        if (not (v_a or v_c)
                and action.get("action") in ("call", "raise", "all_in")
                and _gov_commit_fraction(state, action) >= 0.40):
            try:
                hero_seat = state.get("seat_to_act")
                hero_cards = p.get("cards") or []
                board = state.get("community_cards") or []

                if len(board) >= 3 and len(hero_cards) == 2:
                    k_action = k_stack_off_ev_simulation(
                        state, hero_cards, board, opp_id, action, hero_seat)
                    if k_action is not None and (
                            k_action.get("action") != action.get("action")
                            or k_action.get("amount") != action.get("amount")):
                        _K_CHANGED_ACTION_COUNT += 1
                        action = k_action
            except Exception:
                pass

        try:
            board = state.get("community_cards") or []
            hole = p.get("cards") if p else (state.get("your_cards") or [])
            action = river_pair_transition_guard(state, action, hole, board)
        except Exception:
            pass

        try:
            board = state.get("community_cards") or []
            hole = p.get("cards") if p else (state.get("your_cards") or [])
            al = state.get("action_log") or []
            n_players = len(state.get("players") or [])
            action = multiway_paired_river_supercap(state, action, hole, board, al, n_players)
        except Exception:
            pass
        return action
    except Exception:
        return action

def emergency_fallback(state):
    if state.get("can_check"):
        return {"action": "check"}
    return {"action": "fold"}

def map_to_legal_action(intended, state):
    a = intended.get("action")
    if a == "check" and not state.get("can_check"):
        return {"action": "fold"}
    if a == "raise":
        try:
            amt = int(intended.get("amount", 0))
        except (TypeError, ValueError):
            return emergency_fallback(state)
        min_r = state.get("min_raise_to", 0)
        max_r = state.get("your_stack", 0) + state.get("your_bet_this_street", 0)
        if min_r > max_r:
            return {"action": "call"} if not state.get("can_check") else {"action": "check"}
        if amt >= max_r:
            return {"action": "all_in"}
        return {"action": "raise", "amount": max(amt, min_r)}
    if a in ("fold", "call", "all_in"):
        return {"action": a}
    return emergency_fallback(state)

def parse_state(state):
    return {
        "cards": state.get("your_cards", []) or [],
        "seat": state.get("seat_to_act", 0),
        "street": state.get("street", "preflop"),
        "pot": state.get("pot", 0),
        "owed": state.get("amount_owed", 0),
        "stack": state.get("your_stack", 0),
        "can_check": state.get("can_check", False),
    }

def decide(state):
    global _EQ_DEADLINE, _RNG, _T0
    if state.get("type") == "warmup":
        try:
            eval7.evaluate([eval7.Card("As"), eval7.Card("Kd"), eval7.Card("Qc"),
                            eval7.Card("Jh"), eval7.Card("9s")])
            precompute_preflop_equity(2.0)
        except Exception:
            pass
        return {"action": "check"}

    _T0 = _now()

    _EQ_DEADLINE = min(_T0 + EQ_BUDGET, _T0 + SOFT_BUDGET - 0.15)
    try:
        _RNG = random.Random(_decision_seed(state))
    except Exception:
        _RNG = random
    try:
        try:
            update_opponent_memory(state)
        except Exception:
            pass
        p = parse_state(state)
        if _now() - _T0 > SOFT_BUDGET:
            return emergency_fallback(state)
        if p["street"] == "preflop" and len(p["cards"]) == 2:
            act = preflop_decision(state, p)
        else:
            act = postflop_decision(state, p)

        act = apply_governors(act, state, p)
        return map_to_legal_action(act, state)
    except Exception:
        return emergency_fallback(state)
